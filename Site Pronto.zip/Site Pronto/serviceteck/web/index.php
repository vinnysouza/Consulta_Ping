<!DOCTYPE HTML>
<html>
<head>
<title>VF Soluções em Tecnologia </title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600' rel='stylesheet' type='text/css'>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" type="text/css" href="css/magnific-popup.css">
<link rel="shortcut icon" href="images/favicon.ico" />
<script src="js/jquery.min.js"></script>
</head>
<body>
<!-- start header -->
<div class="header_bg">
<div class="wrap">
	<div id="content">
      <header id="topnav">
        <nav>
        		 <ul>
					<li class="active"><a class="scroll" href="#home">Home</a></li>
                    <li><a class="scroll" href="#team">Empresa</a></li>
					<li><a class="scroll" href="#service">Serviços</a></li>
                    <!--<li><a class="scroll" href="#client">Clientes</a></li>-->
                    <li><a href="http://www.serviceteck.com.br/glpi" target="_blank">Abrir Chamado</a></li>
					<li><a  class="scroll" href="#contact">Contato</a></li>
					<div class="clear"> </div>
				</ul>
        </nav>
         <div class="logo"><a href="index.html"><img src="images/logo.png"></a></div>
        <a href="#" id="navbtn">Nav Menu</a>
        <div class="clear"> </div>
      </header><!-- @end #topnav -->
      <script type="text/javascript"  src="js/menu.js"></script>
    </div>
</div>
</div>
<!--start-slider---->
<div class="slider" id="home"> 
				<div class="wrap">
				<!---start-da-slider----->
				<div id="da-slider" class="da-slider">
				<div class="da-slide">
					<h2>Infraestrutura / Rede</h2>
					<p>A VF Soluções em Tecnologia implanta, otimiza e mantém plataformas e infraestrutura de Tecnologia da Informação para redes locais (LAN) e de conectividade entre unidades (WAN).</p>
					<a href="#service" class="da-link scroll">Leia mais</a>
				</div>
				<div class="da-slide">
					<h2>Segurança da Informação</h2>
					<p>A segurança dos dados da sua empresa são informações muito importante, confira as soluções que oferecemos.</p>
					<a href="#service" class="da-link scroll">Leia mais</a>
				</div>
				<nav class="da-arrows">
					<span class="da-arrows-prev"></span>
					<span class="da-arrows-next"></span>
				</nav>
			</div>
			<link rel="stylesheet" type="text/css" href="css/slider.css" />
			<script type="text/javascript" src="js/modernizr.custom.28468.js"></script>
			<script type="text/javascript" src="js/jquery.cslider.js"></script>
			<script type="text/javascript">
				$(function() {
				
					$('#da-slider').cslider({
						autoplay	: true,
						bgincrement	: 450
					});
				
				});
			</script>
				<!---//End-da-slider----->
			</div>
</div>
<!-----------start-team-------------->
<div class="team" id="team">
				 <div class="wrap">
				 		<div class="heading_h">
							<h3><a href="#">Empresa</a></h3>
						</div>	
				 		<article style="width:100%;text-align:left;float:left;margin-bottom:30px">
                        	<img src="images/company.jpg" height="165px" style="float:left;margin-right:20px">
                            <p>A VF Soluções em Tecnologia IT Solution e uma empresa nova fundada em 2013, visando a qualidade nos serviços de TI. Especializada em tecnologia desde que foi criada, a VF Soluções em Tecnologia tem como sua principal conduta a inovação de seus produtos e serviços. Em qualquer área em que atue, a VF Soluções em Tecnologia oferece consultoria e outsourcing de profissionais de TI nas áreas de: Suporte Técnico, Infraestrutura de Redes e Desenvolvimento de Software, Web Designer, Segurança de Redes, CFTV. </p>
                            </article>
                            <article style="width:100%;text-align:left;float:left;margin-bottom:30px">
                            <p><strong>Valores</strong></p>
                            <ul>
                            	<li>Sempre Prezar pela Satisfação do Cliente;</li>
                                <li>Obter o Máximo na Qualidade do Serviço Prestado;</li>
                                <li>Entusiasmo;</li>
                                <li>Ética;</li>
                                <li>Inovação;</li>
                                <li>Comunicação;</li>
                                <li>Comprometimento;</li>
                                <li>Qualidade;</li>
                                <li>Credibilidade;</li>
                                <li>Respeito;</li>
                                <li>Integridade;</li>
                            </ul>
                            
                            <p style="margin:30px 0 20px"><strong>Missão</strong></p>
                            <p>Ser o melhor provedor de tecnologia, Fornecer soluções eficazes e inovadoras de Tecnologia da Informação e Comunicação (TIC),buscando contribuir para o sucesso e competitividade de nossos clientes através de colaboradores.</p>
                            <p style="margin:30px 0 20px"><strong>Visão</strong></p>
                            <p>Crescer continuamente junto com nossos clientes e com as novas tecnologias.</p>
                        </article>
						<div class="clear"> </div>
					</div>
		 		</div>
</div>
<!----------end-team----------------->
<!-----------portfolio-------------->
<div class="portfolio_main"id ="service">
				<div class="wrap">
					<div class="heading_h">
						<h3><a href="#">Serviços</a></h3>
					</div>
					<!--start-mfp -->	
				<div id="small-dialog1" class="mfp-hide">
					<div class="pop_up">
                               <img src="images/pop1.jpg">
							   	 <h2>Infraestrutura / Rede</h2>
								 <p>A VF Soluções em Tecnologia implanta, otimiza e mantém plataformas e infraestrutura de Tecnologia da Informação para redes locais (LAN) e de conectividade entre unidades (WAN). Seja sua empresa de pequeno ou grande porte, com infraestrutura de menor ou maior complexidade, nossa equipe técnica está capacitada a atendê-lo com serviços, equipamentos e tecnologias alinhados à sua demanda e suas perspectivas de expansão. A infraestrutura de redes é constituída por servidores, switches, equipamentos WiFi, firewalls e outros dispositivos cuja tarefa é a redução de custos para a empresa, disponibilizando recursos para uma operação mais eficaz e uma maior produtividade. Quando bem planejada, a estrutura de redes pode ser uma grande vantagem competitiva.
                                 </p>
                                 <p>
                                     <strong>Infraestrutura de TI básica – soluções integradas para:</strong>
                                     <ul>
                                        <li>Cabeamento Estruturado</li>
                                        <li>Conectar servidores, estações de trabalho, dispositivos móveis e telefonia</li>
                                        <li>Conectar unidades ‒ matriz e filiais</li>
                                        <li>Gerenciar usuários, grupos e permissões de acesso</li>
                                        <li>Estabelecer segurança contra vírus, spam, malware e acesso a recursos</li>
                                        <li>Monitoramento do seu link de internet, seus servidores</li>
                                        <li>Armazenar e restaurar dados</li>
                                        <li>Conexões mais rápidas para maior fluxo de informações</li>
                                     </ul>
                                 </p>
                                 <p>
                                 	<strong>Infraestrutura de TI avançada – soluções integradas para:</strong>
                                    <ul>
                                    	<li>Transmitir comunicações por voz através de Protocolo da Internet (telefonia IP)</li>
                                        <li>Potencializar o desempenho das aplicações que rodam sobre a rede</li>
                                        <li>Virtualizar ambientes de produtividade</li>
                                        <li>Dinamizar e unificar as comunicações (dados, voz e vídeo)</li>
                                        <li>Integrar ferramentas de produtividade</li>
                                        <li>Automatizar o gerenciamento e manutenção da infraestrutura</li>
                                        <li>Monitoramento do seu link de internet, seus servidores</li>
                                    </ul>
                                  </p>
                                  <p class="pop_p">Com um ambiente de tecnologia dinâmico e gerenciado, você reduz o custo operacional e mantém sua empresa funcionando e sua equipe se comunicando. Fale conosco e conheça o melhor caminho para ampliar a performance, conectividade, estabilidade e segurança de suas operações de negócio. </p>
                                  <p>Soluções para Servidores Windows e Linux.</p>
								</div>
					
				</div>
				 <div id="small-dialog2" class="mfp-hide">
							   <div class="pop_up2">
							   <img src="images/pop2.jpg">
							   	 <h2>Suporte a Computadores e Usuários</h2>
								 <p>Trabalhamos pró-ativamente e ativamente em seus computadores, provendo o atendimento esperado e uma vida útil muito superior ao normalmente atingido por seus equipamentos. Contamos com técnicos capacitados a detectar e reparar defeitos de software ou hardware em seus equipamentos. Tudo com comodidade e segurança para você e sua empresa. Retiramos seu equipamento para orçamento e reparo ou, quando possível, realizamos o reparo no local para agilizar o atendimento. A VF Soluções em Tecnologia dispõe de colaboradores com experiência no mercado de TI, aptos a desenvolver atividades de instalação e configuração de servidores, 
estações de trabalho, Firewall, Antivírus, VPN, entre outras. Os serviços são desenvolvidos através de atendimento telefônico, remoto ou de visita presencial para solucionar problemas em seu ambiente tecnológico. Os serviços podem ser contratados através de contrato mensal ou chamada avulsa. Com o suporte técnico da VF Soluções em Tecnologia sua empresa contará com as melhores práticas de gerenciamento dos recursos de TI.</p>
								 <p>
                                     <strong>Oferecemos no Suporte:</strong>
                                     <ul>
                                        <li>Suporte Presencial</li>
                                        <li>Suporte Remoto / Virtual</li>
                                        <li>Suporte Telefônico</li>
                                        <li>Instalação de Softwares</li>
                                        <li>Manutenção Corretiva</li>
                                        <li>Manutenção Preventiva</li>
                                        <li>Treinamento dos usuários</li>
                                        <li>Configuração de E-mails</li>
                                        <li>Configuração de Servidores "Básico"</li>
                                        <li>AD - Politicas de acesso "Básico"</li>
                                        <li>Manutenção de Equipamentos de rede</li>
                                        <li>Relatório Completo de Chamados</li>
                                        <li>Estudo e Desenvolvimento de Melhorias</li>
                                        <li>Planejamento anual de investimentos e TI</li>
                                     </ul>
                                 </p>
                                 <p>
                                     <strong>Benefícios & Vantagens:</strong>
                                     <ul>
                                        <li>Redução de custos</li>
                                        <li>Maior foco em seu negócio</li>
                                        <li>Menor tempo de paradas técnicas</li>
                                        <li>Avaliação frequente de funcionamento</li>
                                        <li>Antecipação à problemas tecnológicos</li>
                                        <li>Continuidade do trabalho da equipe</li>
                                        <li>Atualização tecnológica constante</li>
                                        <li>Profissionais Experientes e Qualificados</li>
                                     </ul>
                                 </p>
								</div>
				 </div>
				 <div id="small-dialog3" class="mfp-hide">
							   <div class="pop_up3">
							   	<img src="images/pop3.jpg">
							   	 <h2>Desenvolvimento de Software</h2>
								 <p>Desenvolvemos softwares sob medida para você potencializando sua capacidade de administração e resultados de produção da sua empresa. Para atender às necessidades específicas de seus negócios, que normalmente não são supridas por produtos disponíveis no mercado, muitas empresas tentam desenvolver internamente seus softwares, o que, na maioria das vezes, não é a melhor alternativa. Segundo estatísticas de mercado, além de exigirem grandes investimentos em equipe e infraestrutura, a grande maioria destes projetos sofre desvios significativos de custo, cronograma e escopo. Como consequência, nem sempre são desenvolvidas todas as funcionalidades desejadas, gerando frustração do usuário e grande desperdício de tempo e recursos.</p>
								 <p>
                                     <strong>Tecnologias e Plataformas:</strong>
                                     <ul>
                                        <li>Web / Internet e Intranet</li>
                                        <li>Mobilidade / Smartphones e Tablets</li>
                                        <li>Computação na Nuvem / SaaS e Web Services</li>
                                     </ul>
                                 </p>
								</div>
				 </div>
				 <div id="small-dialog4" class="mfp-hide">
							   <div class="pop_up4">
							   	<img src="images/pop4.jpg">
							   	 <h2>Web Design</h2>
								 <p>A criação de um site é uma forte ferramenta de marketing, possibilitando que qualquer pessoa do mundo encontre informações sobre produtos e serviços de sua empresa.</p>
            <p>Além disso, é uma excelente forma de estreitar o contato com clientes e fornecedores, tornando-se um importante instrumento para qualquer categoria, segmento ou tamanho de empresa.</p>
								</div>
				 </div>
				 <div id="small-dialog5" class="mfp-hide">
							   <div class="pop_up5">
							   	<img src="images/pop5.jpg">
							   	 <h2>Segurança da Informação</h2>
								 <p>A segurança dos dados da sua empresa são informações muito importante por isso a VF Soluções em Tecnologia oferece as soluções.</p>
								 <p>
                                     <ul>
                                        <li>Proxy</li>
                                        <li>Firewall</li>
                                        <li>Antivírus</li>
                                        <li>IPS</li>
                                        <li>AntiSpam</li>
                                     </ul>
                                 </p>
								</div>
				 </div>
				 <div id="small-dialog6" class="mfp-hide">
							   <div class="pop_up6">
							   	<img src="images/pop6.jpg">
							   	 <h2>Soluções em CFTV</h2>
								 <p>
                                     <strong>CFTV Analógico</strong>
                                 </p>
                                 <p>Um sistema de CFTV tem por finalidade inibir, monitorar e detectar situações em tempo real e possibilitar uma intervenção direta e imediata.</p>
                                 <p>Neste sistema toda a gravação é feita de forma digital e pode ser feita através de alarmes, detecção de movimento ou por horários, ou seja, o sistema não precisa ficar gravando em tempo integral, o que gera maior economia de espaço no HD e mais dias gravados sobre o que realmente interessa.</p>
                                 <p>É possível realizar o monitoramento remoto por meio de computador, tablet ou smartphone, seja de dentro ou de fora da empresa utilizando internet ou VPN.</p>
                                 <p>
                                     <strong>CFTV IP</strong>
                                 </p>
                                 <p>O sistema de CFTV IP é a tecnologia mais avançada atualmente em monitoramento por imagens. Neste sistema as câmeras realizam o envio das imagens para o sistema de gerenciamento utilizando comunicação totalmente digital, ou seja, trata-se de um método de transmissão absolutamente sem perda de qualidade.</p>
                                 <p>As opções de modelos de câmera são as mais diversas, variando entre fixas e móveis, coloridas e Day Night, de resoluções padrão ou HDTV (alta definição). Algumas câmeras superam inclusive a resolução Full HD de um disco Blu-Ray, ou outras ainda possuem captação de imagens térmicas para monitoramento em condições totalmente críticas.</p>
                                 <p>
                                     <strong>Pontos fortes do CFTV IP:K2 AO VIVO:</strong>
                                     <ul>
                                        <li>Transmissão de vídeo sem perda de qualidade;</li>
                                        <li>Alta definição das imagens;</li>
                                        <li>Facilidade de implantação;</li>
                                        <li>Flexibilidade no gerenciamento e operação;</li>
                                        <li>Maior padronização de equipamentos.</li>
                                     </ul>
                                 </p>
								</div>
				 </div>
				<!--end-mfp -->	
				<!--start-content-->
			<div class="gallery">
			<div class="container">
				<div id="gallerylist">
				<div class="gallerylist-wrapper">				
                    <a class="popup-with-zoom-anim" href="#small-dialog1">
                    	<span class="rolloverS"><h3>Infraestrutura / Rede</h3></span>
						<img src="images/gd1.jpg" alt="Image 1"/>
					</a>
				</div>
				<div class="gallerylist-wrapper">				
					<a class="popup-with-zoom-anim" href="#small-dialog2">
						<span class="rolloverS"><h3>Suporte Técnico</h3></span>
                        <img src="images/gd2.jpg"  alt="Image 1"/>
					</a>
				</div>
				<div class="gallerylist-wrapper">				
					<a class="popup-with-zoom-anim" href="#small-dialog3">
						<span class="rolloverS"><h3>Desenvolvimento de Software</h3></span>
                        <img src="images/gd3.jpg"  alt="Image 1"/>
					</a>
				</div>
				<div class="clear"></div>
			</div>		
			<div id="gallerylist1">
				<div class="gallerylist-wrapper">				
					<a class="popup-with-zoom-anim" href="#small-dialog4">
						<span class="rolloverS"><h3>Web Design</h3></span>
                        <img src="images/gd4.jpg" alt="Image 1"/>
					</a>
				</div>
				<div class="gallerylist-wrapper">				
					<a class="popup-with-zoom-anim" href="#small-dialog5">
						<span class="rolloverS"><h3>Segurança de Redes</h3></span>
                        <img src="images/gd5.jpg"  alt="Image 1"/>
					</a>
				</div>
				<div class="gallerylist-wrapper">				
					<a class="popup-with-zoom-anim" href="#small-dialog6">
						<span class="rolloverS"><h3>CFTV</h3></span>
                        <img src="images/gd6.jpg"  alt="Image 1"/>
					</a>
				</div>
					<div class="clear"> </div>
			</div>																																					
		</div>
	</div>
	<!--end container -->
				<script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
				<script>
					$(document).ready(function() {
						$('.popup-with-zoom-anim').magnificPopup({
							type: 'inline',
							fixedContentPos: false,
							fixedBgPos: true,
							overflowY: 'auto',
							closeBtnInside: true,
							preloader: false,
							midClick: true,
							removalDelay: 300,
							mainClass: 'my-mfp-zoom-in'
					});
				});
				</script>
				
		</div>
	</div>
</div>
<!-----------//portfolio//----------->

<!---------text-slider------------->
			
		 <!--<div class="wmuSlider example1" id="client">
		 	<div class="wrap">
			   <div class="heading_h">
                <h3><a href="#">Clientes</a></h3>
            </div>
               <article style="position: absolute; width:64%; opacity: 0;margin-top:-110px"> 
				   	
					<div class="cont span_2_of_3">
						    <h4>O que os clientes dizem...</h1>
							<p>Lorem ipsum is simply dummy text of the printing and typesetting industry.Lorem ipsum has been the printing and typesetting industry's standard dummy text ever since the 500,s when an unknown printer took a gellery of type.</p>
						 
					</div>
				</article>
				 <article style="position: absolute; width:64%; opacity: 0;margin-top:-110px"> 
				   	<div class="cont span_2_of_3">
						    <h4>O que os clientes dizem...</h4>
						    <p>Lorem ipsum is simply dummy text of the printing and typesetting industry.Lorem ipsum has been the printing and typesetting industry's standard dummy text ever since the 500,s when an unknown printer took a gellery of type.</p>
					</div>
				 </article>
				 <article style="position: absolute; width:64%; opacity: 0;margin-top:-110px"> 
				   	<div class="cont span_2_of_3">
						    <h4>O que os clientes dizem...</h4>
						    <p>Lorem ipsum is simply dummy text of the printing and typesetting industry.Lorem ipsum has been the printing and typesetting industry's standard dummy text ever since the 500,s when an unknown printer took a gellery of type.</p>
					</div>
				 </article>
		 
                  <script src="web/js/jquery.wmuSlider.js"></script> 
					<script>
       				     $('.example1').wmuSlider();         
   					</script> 	           	      
	         </div>
	     </div>-->
<!----------//text-slider------------>
<!--------start-contact-----------> 
 <div class="contact" id="contact">
	<div class="wrap">
		<h2>Contato</h2>
			<div class="contact-form">
				<div class="para-contact">
					<h4>Entre em contato conosco</h4>
					<p>Para maiores informações e orçamentos de serviços entre em contato pelo formulário ao lado, ou através dos contatos abaixo.</p>
				
				 	<div class="social_2 social_3">	
			           <ul>	
						    <li class="facebook"><a href="#"><span> </span></a></li>
						    <li class="twitter"><a href="#"><span> </span></a></li>	 	
							<li class="google"><a href="#"><span> </span></a></li>
					  </ul>
		 		  </div>
		 		  <div class="get-intouch-left-address">
						<p>+55 (81) 9.9102.3421</p>
                        <p>+55 (81) 9.9808.3206</p>
						<p><a href="mailto:contato@serviceteck.com.br"> contato@vftecnologia.com.br</a></p>
					</div>
					<div class="clear"> </div>	
				</div>
						<div class="form">
				  			<form method="post" class="contact-form" name="frmMail" id="frmMail" action="mail.php">
							    	<input type="text" class="textbox" name="name" id="name" placeholder="Nome" />
							    	<input type="text" class="textbox" name="email" id="email" placeholder="E-mail">
										<div class="clear"> </div>
								    <div>
								    	<textarea name="message" id="message" placeholder="Mensagem"></textarea>
								    </div>
								<div class="button send_button">
											   	 <input type="submit" name="btenviar" id="btEnviar" value="Enviar">
								</div>
								<div class="clear"> </div>
							</form>
						</div>
						<a class="mov-top" href="#home1"> <span> </span></a>
					 <div class="clear"> </div>
				</div>
  			</div>
     </div>
     <!-- scroll_top_btn -->
		<script type="text/javascript" src="js/move-top.js"></script>
		<script type="text/javascript" src="js/easing.js"></script>
	    <script type="text/javascript">
			$(document).ready(function() {
			
				var defaults = {
		  			containerID: 'toTop', // fading element id
					containerHoverID: 'toTopHover', // fading element hover id
					scrollSpeed: 1200,
					easingType: 'linear' 
		 		};
				
				
				$().UItoTop({ easingType: 'easeOutQuart' });
				
			});
		</script>
		<script type="text/javascript">
		jQuery(document).ready(function($) {
			$(".scroll").click(function(event){		
				event.preventDefault();
				$('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
			});
		});
	</script>

		 <a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 1;"></span></a>
<!--------//end-contact----------->
</body>
</html>		