﻿<?php
	// Passando os dados obtidos pelo formulário para as variáveis abaixo
	$emaildestinatario = 'contato@serviceteck.com.br'; // Digite seu e-mail aqui, lembrando que o e-mail deve estar em seu servidor web
	$emailsender       = 'contato@serviceteck.com.br';
	$assunto           = 'CONTATO - www.serviceteck.com.br';
	$nomeremetente     = $_POST['name'];
	$emailremetente    = trim($_POST['email']);
	$mensagem          = $_POST['message'];
	 
	 
	/* Montando a mensagem a ser enviada no corpo do e-mail. */
	$mensagemHTML = '<p><b>Nome:</b> '.$nomeremetente.'
	<p><b>E-Mail:</b> '.$emailremetente.'
	<p><b>Mensagem:</b> '.$mensagem.'</p>
	<hr />';
	
	
	// O remetente deve ser um e-mail do seu domínio conforme determina a RFC 822.
	// O return-path deve ser ser o mesmo e-mail do remetente.
	$headers = "MIME-Version: 1.1\r\n";
	$headers .= "Content-type: text/html; charset=utf-8\r\n";
	$headers .= "From: ".$nomeremetente. " <".$emailremetente.">\r\n"; // remetente
	$headers .= "Return-Path: " . $emaildestinatario ." \r\n"; // return-path
	$envio = mail($emaildestinatario, $assunto, $mensagemHTML, $headers,"-r".$emailsender); 
	//Enviando o email 
	if ($envio)
		{ 
			//echo "<strong>E-Mail enviado com sucesso!</strong>";
			echo "<script>alert('E-mail enviado com sucesso!');location.href='index.php';</script>";
		} 
	else{ 
			echo "<strong>Falha no envio do E-Mail!</strong>"; 
		} 
 ?>